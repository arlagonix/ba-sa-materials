import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/ba-sa-materials/blog',
    component: ComponentCreator('/ba-sa-materials/blog', 'ef5'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/archive',
    component: ComponentCreator('/ba-sa-materials/blog/archive', '576'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/authors',
    component: ComponentCreator('/ba-sa-materials/blog/authors', '724'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/authors/all-sebastien-lorber-articles',
    component: ComponentCreator('/ba-sa-materials/blog/authors/all-sebastien-lorber-articles', 'b7f'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/authors/yangshun',
    component: ComponentCreator('/ba-sa-materials/blog/authors/yangshun', '127'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/first-blog-post',
    component: ComponentCreator('/ba-sa-materials/blog/first-blog-post', 'c15'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/long-blog-post',
    component: ComponentCreator('/ba-sa-materials/blog/long-blog-post', '167'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/mdx-blog-post',
    component: ComponentCreator('/ba-sa-materials/blog/mdx-blog-post', '715'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/tags',
    component: ComponentCreator('/ba-sa-materials/blog/tags', 'db8'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/tags/docusaurus',
    component: ComponentCreator('/ba-sa-materials/blog/tags/docusaurus', 'c38'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/tags/facebook',
    component: ComponentCreator('/ba-sa-materials/blog/tags/facebook', 'ce5'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/tags/hello',
    component: ComponentCreator('/ba-sa-materials/blog/tags/hello', 'd6e'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/tags/hola',
    component: ComponentCreator('/ba-sa-materials/blog/tags/hola', 'c95'),
    exact: true
  },
  {
    path: '/ba-sa-materials/blog/welcome',
    component: ComponentCreator('/ba-sa-materials/blog/welcome', 'a63'),
    exact: true
  },
  {
    path: '/ba-sa-materials/markdown-page',
    component: ComponentCreator('/ba-sa-materials/markdown-page', 'd87'),
    exact: true
  },
  {
    path: '/ba-sa-materials/summaries',
    component: ComponentCreator('/ba-sa-materials/summaries', '9d5'),
    routes: [
      {
        path: '/ba-sa-materials/summaries',
        component: ComponentCreator('/ba-sa-materials/summaries', 'df8'),
        routes: [
          {
            path: '/ba-sa-materials/summaries',
            component: ComponentCreator('/ba-sa-materials/summaries', 'dcb'),
            routes: [
              {
                path: '/ba-sa-materials/summaries',
                component: ComponentCreator('/ba-sa-materials/summaries', 'af2'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/category/tutorial---basics',
                component: ComponentCreator('/ba-sa-materials/summaries/category/tutorial---basics', '282'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/category/tutorial---extras',
                component: ComponentCreator('/ba-sa-materials/summaries/category/tutorial---extras', '4b5'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/courses',
                component: ComponentCreator('/ba-sa-materials/summaries/courses', 'cb1'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/courses/anthropic-ai-fluency',
                component: ComponentCreator('/ba-sa-materials/summaries/courses/anthropic-ai-fluency', 'b38'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/courses/anthropic-ai-fluency/02-4d-framework',
                component: ComponentCreator('/ba-sa-materials/summaries/courses/anthropic-ai-fluency/02-4d-framework', 'a0d'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/courses/anthropic-ai-fluency/introduction',
                component: ComponentCreator('/ba-sa-materials/summaries/courses/anthropic-ai-fluency/introduction', '37d'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/courses/anthropic-ai-fluency/what-is-ai-fluency',
                component: ComponentCreator('/ba-sa-materials/summaries/courses/anthropic-ai-fluency/what-is-ai-fluency', '427'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/courses/stepik-broker-basics',
                component: ComponentCreator('/ba-sa-materials/summaries/courses/stepik-broker-basics', '4c0'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/courses/stepik-broker-basics/basics',
                component: ComponentCreator('/ba-sa-materials/summaries/courses/stepik-broker-basics/basics', '5fb'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/generative-ai-fundamentals-a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d',
                component: ComponentCreator('/ba-sa-materials/summaries/generative-ai-fundamentals-a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d', '2b1'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/tutorial-basics/congratulations',
                component: ComponentCreator('/ba-sa-materials/summaries/tutorial-basics/congratulations', 'e3f'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/tutorial-basics/create-a-blog-post',
                component: ComponentCreator('/ba-sa-materials/summaries/tutorial-basics/create-a-blog-post', 'b8e'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/tutorial-basics/create-a-document',
                component: ComponentCreator('/ba-sa-materials/summaries/tutorial-basics/create-a-document', 'd8f'),
                exact: true,
                sidebar: "testSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/tutorial-basics/create-a-page',
                component: ComponentCreator('/ba-sa-materials/summaries/tutorial-basics/create-a-page', 'e23'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/tutorial-basics/deploy-your-site',
                component: ComponentCreator('/ba-sa-materials/summaries/tutorial-basics/deploy-your-site', 'b0c'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/tutorial-basics/markdown-features',
                component: ComponentCreator('/ba-sa-materials/summaries/tutorial-basics/markdown-features', 'b23'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/tutorial-extras/manage-docs-versions',
                component: ComponentCreator('/ba-sa-materials/summaries/tutorial-extras/manage-docs-versions', 'b4f'),
                exact: true,
                sidebar: "summariesSidebar"
              },
              {
                path: '/ba-sa-materials/summaries/tutorial-extras/translate-your-site',
                component: ComponentCreator('/ba-sa-materials/summaries/tutorial-extras/translate-your-site', 'e1e'),
                exact: true,
                sidebar: "summariesSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/ba-sa-materials/',
    component: ComponentCreator('/ba-sa-materials/', 'd96'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
