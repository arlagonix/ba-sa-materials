export default [
  require("C:\\Prime\\GitHub\\ba-sa-materials\\.docusaurus\\docusaurus-plugin-css-cascade-layers\\default\\layers.css"),
  require("C:\\Prime\\GitHub\\ba-sa-materials\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Prime\\GitHub\\ba-sa-materials\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Prime\\GitHub\\ba-sa-materials\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Prime\\GitHub\\ba-sa-materials\\src\\css\\custom.css"),
];
